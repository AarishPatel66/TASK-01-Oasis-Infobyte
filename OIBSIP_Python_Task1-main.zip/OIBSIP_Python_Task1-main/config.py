
WEATHER_API_KEY = "<YOUR_OPENWEATHERMAP_API_KEY>"
WEATHER_BASE_URL = "http://api.openweathermap.org/data/2.5/weather"


SMTP_SERVER = "smtp.gmail.com"
SMTP_PORT = 587
MY_EMAIL = "<YOUR_GMAIL_ADDRESS>"
MY_PASSWORD = "<YOUR_GMAIL_APP_PASSWORD>"


MQTT_BROKER = "192.168.1.10" # IP address of your local MQTT broker (e.g, Home Assistant)
MQTT_PORT = 1883
